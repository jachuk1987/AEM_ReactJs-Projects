function validate2(){
var m=document.forms["form2"]["un"].value;
var n=document.forms["form2"]["ps"].value;

if (m==" " || n==" ") {
  alert("Plzz fill username & password..");
  return false;
  }
  document.getElementById("demo").innerHTML= m;
  document.getElementById("demo").innerHTML= n;

}
function validateForm() {
  var x = document.forms["myForm"]["uname"].value;
  var y=document.forms["myForm"]["psw"].value;
  if (x != m || y !=n) {
    alert("Username & Password didn't match...");
    return false;
  }
}

